#ifndef __ARM_EFI_DOM0_H__
#define __ARM_EFI_DOM0_H__

#include <asm/setup.h>

extern struct meminfo acpi_mem;

#endif
